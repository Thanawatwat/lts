-- load the JSON library.
local json = require("json")
local luasql = require("luasql.postgres")

-- Database setting
local db_host = '127.0.0.1';
local db_port = '5432';
local db_name = 'fusionpbx';
local db_username = 'fusionpbx';
local db_password = 'LYWK99PvC5Zb7Y9EakixxzGAQSA';
local env = assert (luasql.postgres())
local dbcon = env:connect(db_name, db_username, db_password, db_host, db_port)

-- set variables environment
local check_string = true
local json_path = "json/LTS.json"
local domain_name = "lufthansa.cans.cc.cans.cc"
local first_row = 2
local last_row = -4

math.randomseed(os.time())
function uuid()
    local random = math.random
    local template ='xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'
    return string.gsub(template, '[xy]', function (c)
        local v = (c == 'x') and random(0, 0xf) or random(8, 0xb)
        return string.format('%x', v)
    end)
end

function openjson(path)
    local result = {}
    local open = io.open
    local file = open(path, "r")
    if not file then return nil end
    local jsonString = file:read "*a"
    file:close()
    local str, delimiter = jsonString:sub(first_row, last_row):gsub('null', '\"\"'), ", "
    for match in (str..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end

function case_direction(call_type)
    local direction = {"local", "inbound", "outbound", "transfer", "conference"}
    return direction[tonumber(call_type)];
end

function insert_cdr(row)
    local sql_column, sql_values = "", ""
    for j in pairs(json.decode(row)) do 
        sql_column = sql_column..','..j
        sql_values = sql_values..','.."'"..json.decode(row)[j].."'"
    end
    local sql = 'INSERT INTO tmp_voxxy_cdr('..sql_column:sub(2)..') VALUES('..sql_values:sub(2)..')'
    local res, serr = dbcon:execute(sql)
    -- print(sql.."\n")
    print("CDR : "..res)
end

function insert_xml_cdr(raw)
    local row = json.decode(raw)
	row.direction = case_direction(row['calltype'])
            local stamp = (os.time({year=string.sub(row['calldate'], 1,4), month=string.sub(row['calldate'], 6,7), day=string.sub(row['calldate'], 9,10), hour=string.sub(row['calldate'], 12,13), min=string.sub(row['calldate'], 15,16), sec=string.sub(row['calldate'], 18,19)}))
	    local sql = 'select domain_uuid from v_domains WHERE domain_name = \''..domain_name..'\''
            local cursor, serr = dbcon:execute(sql)
            local rows = cursor:fetch ({}, "a")
            if rows then
                local source = ''
                if (row['src'] ~= '') then
                    source = row['src']
                elseif (row['source'] ~= '') then
                    source = row['source']
                end

                local destination = ''
                if (row['dst'] ~= '') then
                    destination = row['dst']
                elseif (row['destination'] ~= '') then
                    destination = row['destination']
                end

                sql = 'insert into v_xml_cdr('
                sql = sql..'xml_cdr_uuid,'
                sql = sql..'domain_uuid,'
                --sql = sql..'extension_uuid,'
                sql = sql..'start_stamp,'
                sql = sql..'answer_stamp,'
                sql = sql..'end_stamp,'
                sql = sql..'start_epoch,'
                sql = sql..'answer_epoch,'
                sql = sql..'end_epoch,'
                sql = sql..'duration,'
                sql = sql..'billsec,'
                sql = sql..'domain_name,'
                sql = sql..'accountcode,'
                sql = sql..'context,'
                sql = sql..'caller_id_name,'
                sql = sql..'caller_id_number,'
                sql = sql..'caller_destination,'
                sql = sql..'destination_number,'
                sql = sql..'hangup_cause,'
		sql = sql..'direction,'
                sql = sql..'json,'
                sql = sql..'leg'
                
                sql = sql..') values('
                sql = sql..'\''..uuid()..'\','
                sql = sql..'\''..rows.domain_uuid..'\','
                --sql = sql..'\''..rows.extension_uuid..'\','
                sql = sql..'\''..row['calldate']..'\','
                sql = sql..'\''..row['calldate']..'\','
                sql = sql..'\''..row['calldate']..'\','
                sql = sql..stamp..','
                sql = sql..stamp..','
                sql = sql..stamp..','
                sql = sql..row['duration']..','
                sql = sql..row['billsec']..','
                sql = sql..'\''..domain_name..'\','
                sql = sql..'\''..row['accountcode']..'\','
                sql = sql..'\''..row['dcontext']..'\','
                sql = sql..'\''..source..'\','
                sql = sql..'\''..source..'\','
                sql = sql..'\''..destination..'\','
                sql = sql..'\''..destination..'\','
                sql = sql..'\''..row['disposition']..'\','
		sql = sql..'\''..row['direction']..'\','
                sql = sql..'\'{ "variables": '..raw..'}\','
                sql = sql..'\'a\''
                sql = sql..')'
                -- print(sql..'\n')
            end
        -- insert variables
            local res, serr = dbcon:execute(sql)
            if(serr) then
		print(serr)
	    end
    end


-- main functions
    local data = openjson(json_path)
    local count, max = 1, 0
    for _ in pairs(data) do
	max = max + 1
    end
	print('\nMigration Total: '..max..' Rows')
    for i in pairs(data) do
	if (check_string and (count == 1 or count == max))  then print(data[i])	end 
        --insert_cdr(data[i])
        --insert_xml_cdr(data[i])
	count = count + 1
    end
    print('Migration End!!!\n')
    dbcon:close()
    env:close()
    

    


-- create table migrate_cdr(cdr_id text, calldate text, clid text, source text, src text, dst text, destination text, dcontext text, channel text, dstchannel text, lastapp text, lastdata text, duration text, billsec text, disposition text, amaflags text, accountcode text, auth_code text, customer_code text, pin_code text, userfield text, uniqueid text, linkedid text, sequence text, peeraccount text, calltype text, recfile text, tenant text, recfile_cloud text, charge text, chargebuy text, cleartext text, unit text, chargeunit text);

-- create table call_result_log(id SERIAL PRIMARY KEY, ref_id TEXT, caller TEXT, callee TEXT, type TEXT, disposition TEXT, duration int, start_time TEXT, end_time TEXT, answer_time TEXT, ref_key TEXT, status TEXT, create_time int);

